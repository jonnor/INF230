python pyGrabDavis3.py -c . -w <WSID> -d -r <yourusername> -p <yourpassword> -b <yourdatabase> -t <WSID_yourtable> -o <WSID_yourstation.csv> -u "http://www.weatherlink.com/user/<yourstation>/index.php?view=summary&headers=0&type=1"
pause
