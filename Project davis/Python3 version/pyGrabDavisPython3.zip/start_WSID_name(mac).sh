python pyGrabDavis3.py -w <WSID> -c . -o <WSID_yourstation.csv> -u "http://www.weatherlink.com/user/<yourstation>/index.php?view=summary&headers=0&type=1"
pause