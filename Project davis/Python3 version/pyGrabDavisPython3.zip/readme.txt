Before you start:
-----------------------------------------------------------
Find some weather stations and its webpage URL and choose a wsid for each of the stations. 

You can browse the stations from this page:
https://www.weatherlink.com/map.php

For the script to work you have to choose "summary" and "metric" units (otherwise you might get farenheit etc).
Also choose "no headers". Once this is done, copy and save the URL web adress.

The files:
-----------------------------------------------------------
The .bat/.sh files runs the python script pyGrabDavis3.py which collects data
from a web page and saves it to csv and/or database. The python file needs input
arguments in the form:

python pyGrabDavis3.py -c . -w <WSID> -d -r <yourusername> -p <yourpassword> -b <yourdatabase> -t <WSID_yourtable> -o <WSID_yourstation.csv> -u "http://www.weatherlink.com/user/woodbebetter/index.php?view=summary&headers=0&type=1"

The <> items must be replaced by values for your database/station.

You can start the python file from the command line yourself, but the .bat/.sh files have been set up
to run the python files as well.

The start_WSID_name file is set up to only log to csv.
The start_WSID_name_database file is set up to log to both csv and database.
You can change this depending on what input arguments you pass to the python script in the .bat/.sh file.

What to do:
-----------------------------------------------------------
Create copies of the .bat files (windows) or .sh files (mac).

Rename the .bat/.sh files so that WSID is the wsid (chosen by you) and replace 
name with the name of your weather station. Note that the name of the .bat/.sh
file has no effect other than making it easier for you to recognize your .bat/.sh files
(file extension .bat/.sh must be kept though).

Edit both copies (text editor) so that they log from the correct URL and 
save the data to the correct file/database. This is done by changing the input arguments
that are fed into the python file.

If you want to log to a table in a database, you will have to create that table/database with the
correct columns in your database system first (the script files don't do this for you).

It is a good idea to run the file that only logs to csv first and then look at the result to know
which columns you need and which data types each column in the table needs.

Once the editing is done and table/database has been created, double click the .bat/.sh file you want to run (only csv or both)
and leave the command window open to continue logging.

If there are error messages, read them and make adjustments accordingly. Also check if the database/csv file
acctually gets filled with the correct data.

NOTE:
If you have a csv file open in excel, the script can't access the file.